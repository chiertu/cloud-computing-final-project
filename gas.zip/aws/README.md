## AWS User Data
This directory should contain AWS user data files only:
* `user_data_web_server.txt` - Configures instances launched by the web app autoscaler
* `user_data_annotator.txt` - Configures instances launched by the annotator autoscaler
* (Optional) `user_data_utils.txt` - Configures utility instances to auto-run all utility scripts
