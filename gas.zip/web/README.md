## GAS Web Server
This directory contains the Flask-based web app for the GAS.

You will add code to `views.py` and add/update Jinja2 templates in `/templates`. Your constants (e.g., queue names) must be declared in `config.py` and accessed via the `app.config` object.
